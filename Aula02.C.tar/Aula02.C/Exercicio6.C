int main()
{

float massa, recomendacao;

printf("Digite a massa corporal em quilogramas: ");
scanf("%f", &massa);

recomendacao = massa * 35;

printf("A recomendação de água para o corpo é: %.2f litros\n", recomendacao);

return 0;
}